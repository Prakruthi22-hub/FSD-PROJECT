import React, { useEffect, useMemo, useState } from "react";

const DELIVERY = 50;

const PERFUMES = [
  { id: 1, name: "Classic Floral", brand: "Maison Lumiere", type: "Floral", price: 999, img: "images/perfume1.webp" },
  { id: 2, name: "Fresh Citrus", brand: "Oceanica", type: "Citrus", price: 1249, img: "images/perfume2.webp" },
  { id: 3, name: "Oriental Spice", brand: "Noir Atelier", type: "Oriental", price: 1699, img: "images/perfume3.webp" },
  { id: 4, name: "Woody Musk", brand: "Terra Scent", type: "Woody", price: 1450, img: "images/perfume4.webp" },
  { id: 5, name: "Fresh Aquatic", brand: "AquaViva", type: "Aquatic", price: 1325, img: "images/perfume5.webp" },
  { id: 6, name: "Sweet Gourmand", brand: "Sugar Atelier", type: "Gourmand", price: 1799, img: "images/perfume6.webp" },
  { id: 7, name: "Fruity Bloom", brand: "Fleur", type: "Fruity", price: 1199, img: "images/perfume7.webp" },
  { id: 8, name: "Musk Sensation", brand: "Velour", type: "Musk", price: 1550, img: "images/perfume8.webp" },
  { id: 9, name: "Spicy Oud", brand: "Noir Oud", type: "Spicy", price: 1899, img: "images/perfume9.webp" },
  { id: 10, name: "Green Fresh", brand: "Herbalist", type: "Green", price: 1399, img: "images/perfume10.webp" }
];

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (m) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]
  ));
}

function App() {
  const [cart, setCart] = useState({});
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("featured");
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState("cod");
  const [isPlacing, setIsPlacing] = useState(false);

  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    addr1: "",
    addr2: "",
    city: "",
    pincode: "",
    state: "",
    country: "India",
    upi: "",
    cardNumber: "",
    cardExp: "",
    cardCvv: ""
  });

  // Load cart from localStorage
  useEffect(() => {
    const stored = localStorage.getItem("perfume_cart");
    if (stored) {
      try {
        setCart(JSON.parse(stored));
      } catch {}
    }
  }, []);

  // Save cart to localStorage
  useEffect(() => {
    localStorage.setItem("perfume_cart", JSON.stringify(cart));
  }, [cart]);

  const cartCount = useMemo(
    () => Object.values(cart).reduce((n, i) => n + i.quantity, 0),
    [cart]
  );

  const subtotal = useMemo(
    () => Object.values(cart).reduce((s, i) => s + i.price * i.quantity, 0),
    [cart]
  );
  const total = subtotal ? subtotal + DELIVERY : 0;

  const filteredPerfumes = useMemo(() => {
    let list = [...PERFUMES];
    const q = search.toLowerCase();
    if (q) {
      list = list.filter((p) =>
        (p.name + p.brand + p.type).toLowerCase().includes(q)
      );
    }
    if (sort === "price-asc") list.sort((a, b) => a.price - b.price);
    if (sort === "price-desc") list.sort((a, b) => b.price - a.price);
    if (sort === "name-asc") list.sort((a, b) => a.name.localeCompare(b.name));
    return list;
  }, [search, sort]);

  function setImgFallback(e) {
    e.target.src = "https://via.placeholder.com/300x250?text=Image";
  }

  function addToCart(id) {
    const p = PERFUMES.find((x) => x.id === id);
    setCart((prev) => {
      const key = String(id);
      const existing = prev[key];
      const updated = {
        ...prev,
        [key]: existing
          ? { ...existing, quantity: existing.quantity + 1 }
          : { ...p, quantity: 1 }
      };
      return updated;
    });
    setIsCartOpen(true);
    setIsCheckoutOpen(false);
  }

  function changeQty(id, delta) {
    setCart((prev) => {
      const key = String(id);
      const copy = { ...prev };
      if (!copy[key]) return prev;
      copy[key] = { ...copy[key], quantity: copy[key].quantity + delta };
      if (copy[key].quantity <= 0) delete copy[key];
      return copy;
    });
  }

  function removeFromCart(id) {
    setCart((prev) => {
      const copy = { ...prev };
      delete copy[String(id)];
      return copy;
    });
  }

  function resetCheckout() {
    setIsCheckoutOpen(false);
    setPaymentMethod("cod");
    setForm((f) => ({
      ...f,
      upi: "",
      cardNumber: "",
      cardExp: "",
      cardCvv: ""
    }));
  }

  function validate() {
    if (!form.name.trim()) return "Enter full name";
    if (!/^[6-9]\d{9}$/.test(form.phone.trim())) return "Invalid phone";
    if (!form.addr1.trim()) return "Address required";
    if (!form.city.trim()) return "City required";
    if (!/^[1-9]\d{5}$/.test(form.pincode.trim())) return "PIN code invalid";
    if (!form.state.trim()) return "State required";

    if (paymentMethod === "upi") {
      if (!form.upi.trim() || !form.upi.includes("@"))
        return "Invalid UPI ID";
    }

    if (paymentMethod === "card") {
      if (form.cardNumber.trim().length < 12)
        return "Invalid card number";
    }
    return null;
  }

  async function handlePlaceOrder() {
    const error = validate();
    if (error) {
      alert(error);
      return;
    }
    if (!Object.keys(cart).length) {
      alert("Cart empty!");
      return;
    }

    const order = {
      customer: form.name.trim(),
      phone: form.phone.trim(),
      email: form.email.trim(),
      address: {
        line1: form.addr1.trim(),
        line2: form.addr2.trim(),
        city: form.city.trim(),
        state: form.state.trim(),
        pincode: form.pincode.trim(),
        country: form.country.trim()
      },
      items: cart,
      total: `₹${total}`,
      payment: paymentMethod,
      paymentInfo:
        paymentMethod === "upi"
          ? { upi: form.upi.trim() }
          : paymentMethod === "card"
          ? { card: form.cardNumber.trim() }
          : {}
    };

    setIsPlacing(true);

    try {
      // send to backend (Node + Express + MongoDB)
      const res = await fetch("http://localhost:5000/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(order)
      });

      const data = await res.json();

      // also keep a local copy (like original)
      const existing = JSON.parse(
        localStorage.getItem("perfume_orders") || "[]"
      );
      existing.push({ ...order, id: data.orderId || Date.now() });
      localStorage.setItem("perfume_orders", JSON.stringify(existing));

      // clear cart & close
      setCart({});
      resetCheckout();
      setIsCartOpen(false);

      alert(
        `Order placed!\nOrder ID: ${data.orderId || "ORD" + Date.now()}\nWe will contact you at ${order.phone}`
      );
    } catch (err) {
      console.error(err);
      alert("Error placing order. Please try again.");
    } finally {
      setIsPlacing(false);
    }
  }

  const cartItemsArray = Object.values(cart);

  return (
    <>
      <header>
        <div className="brand">
          <div className="logo">🌸</div>
          <div>
            <h1>EarthBloom Series</h1>
            <p className="subtitle">Curated scents • Fast delivery across India</p>
          </div>
        </div>

        <div className="controls">
          <input
            id="search"
            placeholder="Search perfumes, brand or type..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <select
            id="sort"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            <option value="featured">Featured</option>
            <option value="price-asc">Price: Low → High</option>
            <option value="price-desc">Price: High → Low</option>
            <option value="name-asc">Name: A → Z</option>
          </select>
          <button
            id="open-cart"
            className="cart-btn"
            onClick={() => {
              setIsCartOpen(true);
              setIsCheckoutOpen(false);
            }}
          >
            Cart (<span id="cart-count">{cartCount}</span>)
          </button>
        </div>
      </header>

      <main>
        <section id="catalog" className="catalog">
          {filteredPerfumes.map((p) => (
            <article className="card" key={p.id}>
              <div className="media">
                <img
                  src={p.img}
                  alt={escapeHtml(p.name)}
                  onError={setImgFallback}
                />
              </div>
              <div>
                <div className="meta">
                  <div>
                    <div className="title">{p.name}</div>
                    <div className="brandline">
                      {p.brand} • {p.type}
                    </div>
                  </div>
                  <div className="price">₹{p.price.toFixed(2)}</div>
                </div>
                <div className="actions">
                  <button
                    className="btn primary add-btn"
                    onClick={() => addToCart(p.id)}
                  >
                    Add to Cart
                  </button>
                  <button
                    className="btn ghost details-btn"
                    onClick={() => alert(`${p.name}\n${p.brand}`)}
                  >
                    View
                  </button>
                </div>
              </div>
            </article>
          ))}
        </section>
      </main>

      {/* CART DRAWER */}
      <aside
        id="cart-drawer"
        className={`cart-drawer ${isCartOpen ? "open" : ""}`}
      >
        <div className="cart-head">
          <h3>Your Cart</h3>
          <button
            id="close-cart"
            className="btn"
            onClick={() => {
              setIsCartOpen(false);
              resetCheckout();
            }}
          >
            ✕
          </button>
        </div>

        {/* CART ITEMS */}
        <div className="cart-body" id="cart-items">
          {cartItemsArray.length === 0 && (
            <div className="small">Your cart is empty.</div>
          )}
          {cartItemsArray.map((item) => (
            <div className="cart-item" key={item.id}>
              <img src={item.img} alt={item.name} onError={setImgFallback} />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700 }}>{item.name}</div>
                <div className="small">
                  {item.brand} • {item.type}
                </div>
              </div>

              <div style={{ textAlign: "right" }}>
                <div className="qty-controls">
                  <button className="dec" onClick={() => changeQty(item.id, -1)}>
                    -
                  </button>
                  <span>{item.quantity}</span>
                  <button className="inc" onClick={() => changeQty(item.id, 1)}>
                    +
                  </button>
                </div>
                <div style={{ marginTop: 8, fontWeight: 700 }}>
                  ₹{(item.price * item.quantity).toFixed(2)}
                </div>
                <button
                  className="btn"
                  style={{ marginTop: 6, background: "#ff4d4f", color: "#fff", border: 0 }}
                  onClick={() => removeFromCart(item.id)}
                >
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* CHECKOUT FORM */}
        <div
          className={`checkout-form ${isCheckoutOpen ? "active" : ""}`}
          id="checkout-form"
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center"
            }}
          >
            <strong>Shipping & Payment</strong>
            <button
              id="cancel-checkout"
              className="btn"
              onClick={() => resetCheckout()}
            >
              Back
            </button>
          </div>

          <div className="field">
            <label>Full name</label>
            <input
              id="cust-name"
              required
              placeholder="e.g. Priya Sharma"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          </div>

          <div className="field">
            <label>Phone</label>
            <input
              id="cust-phone"
              inputMode="numeric"
              required
              placeholder="9876543210"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
            />
          </div>

          <div className="field">
            <label>Email</label>
            <input
              id="cust-email"
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
          </div>

          <div className="field">
            <label>Address line 1</label>
            <input
              id="addr-line1"
              required
              placeholder="House, building, street"
              value={form.addr1}
              onChange={(e) => setForm({ ...form, addr1: e.target.value })}
            />
          </div>

          <div className="field">
            <label>Address line 2 (optional)</label>
            <input
              id="addr-line2"
              placeholder="Area, locality"
              value={form.addr2}
              onChange={(e) => setForm({ ...form, addr2: e.target.value })}
            />
          </div>

          <div style={{ display: "flex", gap: 8 }}>
            <div style={{ flex: 1 }} className="field">
              <label>City</label>
              <input
                id="city"
                required
                placeholder="City"
                value={form.city}
                onChange={(e) => setForm({ ...form, city: e.target.value })}
              />
            </div>
            <div style={{ width: 120 }} className="field">
              <label>PIN code</label>
              <input
                id="pincode"
                inputMode="numeric"
                required
                placeholder="PIN"
                value={form.pincode}
                onChange={(e) => setForm({ ...form, pincode: e.target.value })}
              />
            </div>
          </div>

          <div style={{ display: "flex", gap: 8 }}>
            <div style={{ flex: 1 }} className="field">
              <label>State</label>
              <input
                id="state"
                required
                placeholder="State"
                value={form.state}
                onChange={(e) => setForm({ ...form, state: e.target.value })}
              />
            </div>
            <div style={{ width: 120 }} className="field">
              <label>Country</label>
              <input
                id="country"
                required
                value={form.country}
                onChange={(e) => setForm({ ...form, country: e.target.value })}
              />
            </div>
          </div>

          <div className="field">
            <label>Payment method</label>
            <div className="payment-methods">
              <label>
                <input
                  type="radio"
                  name="pay"
                  value="cod"
                  checked={paymentMethod === "cod"}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                />{" "}
                Cash on Delivery (COD)
              </label>
              <label>
                <input
                  type="radio"
                  name="pay"
                  value="upi"
                  checked={paymentMethod === "upi"}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                />{" "}
                UPI
              </label>
              <label>
                <input
                  type="radio"
                  name="pay"
                  value="card"
                  checked={paymentMethod === "card"}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                />{" "}
                Card (mock)
              </label>
            </div>
          </div>

          {/* Payment extra fields */}
          {paymentMethod === "upi" && (
            <div
              id="payment-extra"
              style={{ display: "flex", flexDirection: "column", gap: 8 }}
            >
              <div className="field">
                <label>UPI ID</label>
                <input
                  id="upi-id"
                  placeholder="yourid@okicici"
                  value={form.upi}
                  onChange={(e) => setForm({ ...form, upi: e.target.value })}
                />
              </div>
            </div>
          )}

          {paymentMethod === "card" && (
            <div
              id="payment-extra"
              style={{ display: "flex", flexDirection: "column", gap: 8 }}
            >
              <div className="field">
                <label>Card Number</label>
                <input
                  id="card-number"
                  placeholder="4242 4242 4242 4242"
                  value={form.cardNumber}
                  onChange={(e) =>
                    setForm({ ...form, cardNumber: e.target.value })
                  }
                />
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <div className="field" style={{ flex: 1 }}>
                  <label>Expiry</label>
                  <input
                    id="card-exp"
                    placeholder="08/28"
                    value={form.cardExp}
                    onChange={(e) =>
                      setForm({ ...form, cardExp: e.target.value })
                    }
                  />
                </div>
                <div className="field" style={{ width: 120 }}>
                  <label>CVV</label>
                  <input
                    id="card-cvv"
                    placeholder="123"
                    value={form.cardCvv}
                    onChange={(e) =>
                      setForm({ ...form, cardCvv: e.target.value })
                    }
                  />
                </div>
              </div>
            </div>
          )}

          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <button
              id="place-order"
              className="btn primary"
              style={{ flex: 1 }}
              onClick={handlePlaceOrder}
              disabled={isPlacing}
            >
              {isPlacing ? "Processing..." : "Place Order"}
            </button>
          </div>

          <div className="hint">
            By placing the order you agree to our terms. This demo uses a mock
            payment flow — no real payments are sent.
          </div>
        </div>

        {/* CART FOOTER */}
        {!isCheckoutOpen && (
          <div className="cart-foot" id="cart-foot">
            <div className="row">
              <span>Subtotal</span>
              <strong id="subtotal">₹{subtotal}</strong>
            </div>
            <div className="row">
              <span>Delivery</span>
              <strong id="delivery-charge">₹{DELIVERY}</strong>
            </div>
            <div className="row total">
              <span>Total</span>
              <strong id="total-cost">₹{total}</strong>
            </div>
            <button
              id="checkout"
              className="btn primary"
              style={{ width: "100%", marginTop: 10 }}
              disabled={cartItemsArray.length === 0}
              onClick={() => setIsCheckoutOpen(true)}
            >
              Checkout
            </button>
          </div>
        )}
      </aside>

      {/* OVERLAY */}
      <div
        id="overlay"
        className={`overlay ${isCartOpen ? "show" : ""}`}
        hidden={!isCartOpen}
        onClick={() => {
          setIsCartOpen(false);
          resetCheckout();
        }}
      ></div>
    </>
  );
}

export default App;
