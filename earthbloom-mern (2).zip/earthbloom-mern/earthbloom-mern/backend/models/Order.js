// backend/models/Order.js
const mongoose = require("mongoose");

const OrderSchema = new mongoose.Schema(
  {
    customer: String,
    phone: String,
    email: String,
    address: {
      line1: String,
      line2: String,
      city: String,
      state: String,
      pincode: String,
      country: String,
    },
    items: {},
    total: String,
    payment: String,
    paymentInfo: {},
  },
  { timestamps: true }
);

module.exports = mongoose.model("Order", OrderSchema);
