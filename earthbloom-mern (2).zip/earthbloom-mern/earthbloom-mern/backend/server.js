// backend/server.js
const express = require("express");
const cors = require("cors");

const app = express();

// middlewares
app.use(cors());
app.use(express.json());

// In-memory orders array (resets when server restarts)
const orders = [];

// simple root
app.get("/", (req, res) => {
  res.send("EarthBloom backend running (NO MongoDB)");
});

// create order
app.post("/api/orders", (req, res) => {
  const order = { ...req.body, _id: "ORD" + Date.now() };
  orders.push(order);
  console.log("New order:", order);
  res.status(201).json({ success: true, orderId: order._id });
});

// (optional) get all orders
app.get("/api/orders", (req, res) => {
  res.json(orders);
});

const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
